## Command Lines

### docker compose up
### docker compose watch